from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class Material:
    filename: str
    text: str
    source_type: str = "unknown"
    char_count: int = 0


@dataclass
class AgentResult:
    topic: str
    materials: List[Material] = field(default_factory=list)
    document_summaries: List[Dict[str, Any]] = field(default_factory=list)
    literature_matrix: List[Dict[str, Any]] = field(default_factory=list)
    institution_analysis: List[Dict[str, Any]] = field(default_factory=list)
    case_matrix: List[Dict[str, Any]] = field(default_factory=list)
    research_gap: Dict[str, Any] = field(default_factory=dict)
    thesis_plan: Dict[str, Any] = field(default_factory=dict)
    verification: Dict[str, Any] = field(default_factory=dict)
    token_usage: Dict[str, Any] = field(default_factory=dict)
