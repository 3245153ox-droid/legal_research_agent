from pathlib import Path
from typing import Iterable, List

from pypdf import PdfReader
from docx import Document

from .schemas import Material


SUPPORTED_EXTENSIONS = {".txt", ".md", ".pdf", ".docx"}


def guess_source_type(filename: str, text: str) -> str:
    name = filename.lower()
    probe = (filename + "\n" + text[:1500]).lower()

    if any(k in probe for k in ["判决书", "裁定书", "判词", "裁判理由", "本院认为"]):
        return "司法案例/判词"
    if any(k in probe for k in ["条例", "办法", "规定", "通知", "意见", "中华人民共和国"]):
        return "法规政策"
    if any(k in probe for k in ["摘要", "关键词", "参考文献", "abstract", "研究"]):
        return "论文文献"
    if name.endswith(".md") or "笔记" in probe:
        return "研究笔记"
    return "未知材料"


def read_txt_or_md(path: Path) -> str:
    for enc in ("utf-8", "utf-8-sig", "gb18030"):
        try:
            return path.read_text(encoding=enc)
        except UnicodeDecodeError:
            continue
    return path.read_text(errors="ignore")


def read_pdf(path: Path) -> str:
    reader = PdfReader(str(path))
    pages = []
    for page in reader.pages:
        try:
            pages.append(page.extract_text() or "")
        except Exception:
            pages.append("")
    return "\n\n".join(pages)


def read_docx(path: Path) -> str:
    doc = Document(str(path))
    return "\n".join(p.text for p in doc.paragraphs if p.text.strip())


def normalize_text(text: str) -> str:
    lines = [line.strip() for line in text.replace("\r", "\n").split("\n")]
    cleaned = []
    prev_blank = False
    for line in lines:
        blank = not line
        if blank and prev_blank:
            continue
        cleaned.append(line)
        prev_blank = blank
    return "\n".join(cleaned).strip()


def load_file(path: Path) -> Material:
    suffix = path.suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"不支持的文件类型：{path.name}")

    if suffix in {".txt", ".md"}:
        text = read_txt_or_md(path)
    elif suffix == ".pdf":
        text = read_pdf(path)
    elif suffix == ".docx":
        text = read_docx(path)
    else:
        text = ""

    text = normalize_text(text)
    return Material(
        filename=path.name,
        text=text,
        source_type=guess_source_type(path.name, text),
        char_count=len(text),
    )


def load_materials(input_path: str | Path) -> List[Material]:
    p = Path(input_path)
    if not p.exists():
        raise FileNotFoundError(f"输入路径不存在：{p}")

    paths: Iterable[Path]
    if p.is_file():
        paths = [p]
    else:
        paths = sorted(x for x in p.iterdir() if x.suffix.lower() in SUPPORTED_EXTENSIONS)

    materials = []
    for path in paths:
        mat = load_file(path)
        if mat.text:
            materials.append(mat)
    return materials
