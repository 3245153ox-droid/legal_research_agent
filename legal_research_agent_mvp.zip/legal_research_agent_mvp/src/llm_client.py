import json
import os
import re
from typing import Any, Dict, List

from dotenv import load_dotenv
from openai import OpenAI
from tenacity import retry, stop_after_attempt, wait_exponential


load_dotenv()


def extract_json(text: str) -> Dict[str, Any]:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text).strip()
        text = re.sub(r"```$", "", text).strip()

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    match = re.search(r"\{.*\}", text, flags=re.S)
    if match:
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            pass

    raise ValueError(f"模型没有返回合法 JSON：\n{text[:1000]}")


class LLMClient:
    def __init__(self) -> None:
        self.api_key = os.getenv("LLM_API_KEY", "")
        self.base_url = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")
        self.model = os.getenv("LLM_MODEL", "gpt-4o-mini")
        self.mock_mode = os.getenv("MOCK_MODE", "true").lower() == "true"
        self.usage_records: List[Dict[str, Any]] = []

        self.client = None
        if not self.mock_mode:
            if not self.api_key:
                raise RuntimeError("LLM_API_KEY 为空。请在 .env 中填写，或设置 MOCK_MODE=true。")
            self.client = OpenAI(api_key=self.api_key, base_url=self.base_url)

    def estimate_tokens(self, text: str) -> int:
        if not text:
            return 0
        chinese_chars = sum(1 for ch in text if "\u4e00" <= ch <= "\u9fff")
        other_chars = len(text) - chinese_chars
        return int(chinese_chars / 1.5 + other_chars / 4) + 1

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=1, max=8))
    def chat_json(self, system_prompt: str, user_prompt: str, task_name: str = "unknown") -> Dict[str, Any]:
        if self.mock_mode:
            return self._mock_response(task_name, user_prompt)

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        prompt_tokens_est = self.estimate_tokens(system_prompt + "\n" + user_prompt)

        resp = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=0.2,
        )

        content = resp.choices[0].message.content or ""
        data = extract_json(content)

        completion_tokens_est = self.estimate_tokens(content)
        record = {
            "task_name": task_name,
            "prompt_tokens_est": prompt_tokens_est,
            "completion_tokens_est": completion_tokens_est,
            "total_tokens_est": prompt_tokens_est + completion_tokens_est,
        }

        usage = getattr(resp, "usage", None)
        if usage:
            record.update({
                "prompt_tokens": getattr(usage, "prompt_tokens", None),
                "completion_tokens": getattr(usage, "completion_tokens", None),
                "total_tokens": getattr(usage, "total_tokens", None),
            })

        self.usage_records.append(record)
        return data

    def _mock_response(self, task_name: str, user_prompt: str) -> Dict[str, Any]:
        prompt_tokens_est = self.estimate_tokens(user_prompt)
        completion_tokens_est = 650
        self.usage_records.append({
            "task_name": task_name,
            "prompt_tokens_est": prompt_tokens_est,
            "completion_tokens_est": completion_tokens_est,
            "total_tokens_est": prompt_tokens_est + completion_tokens_est,
            "mock": True,
        })

        if task_name == "document_summary":
            return {
                "filename": "由 Agent 自动识别",
                "source_type": "论文文献/法规政策/案例判词/研究笔记",
                "research_object": "平台用工中新就业形态劳动者权益保障的制度运行问题。",
                "core_concepts": ["平台用工", "劳动关系认定", "算法控制", "职业伤害保障", "集体协商"],
                "main_argument": "该材料可用于说明平台用工治理的核心难点不只是规则缺失，而是平台控制事实、责任分配和救济路径之间存在断裂。",
                "usable_evidence": [
                    "平台通过派单规则、评价机制、封号机制影响劳动者行为。",
                    "劳动关系认定会影响仲裁、诉讼、工伤认定和社会保险待遇。",
                    "职业伤害保障与集体协商机制可作为分层保护路径。"
                ],
                "possible_use": "可用于文献综述、制度背景、问题意识和论文选题比较部分。",
                "risks": ["正式写作前需要回到原文核对出处、页码、法条和案例名称。"]
            }

        if task_name == "literature_matrix":
            return {"items": [
                {
                    "文献名称": "新就业形态劳动者权益保障研究笔记",
                    "材料类型": "研究笔记",
                    "研究对象": "平台劳动者权益保障机制",
                    "核心观点": "平台治理的核心问题在于算法控制、责任分配和救济路径之间的不匹配。",
                    "解决的问题": "解释为什么传统劳动关系认定标准难以完全覆盖平台用工。",
                    "留下的空白": "需要进一步用案例或判词证明裁判者如何识别平台控制事实。",
                    "可用于论文位置": "绪论的问题提出、第二章文献综述、第三章制度分析"
                },
                {
                    "文献名称": "平台用工权益保障政策材料",
                    "材料类型": "法规政策",
                    "研究对象": "平台企业劳动保障义务与治理措施",
                    "核心观点": "政策路径倾向于通过分层保障、职业伤害保障、协商机制改善平台劳动者保护。",
                    "解决的问题": "提供制度背景和规范目的。",
                    "留下的空白": "政策文本本身不能证明实施效果，需要补充案例或调研材料。",
                    "可用于论文位置": "制度背景与规范分析部分"
                }
            ]}

        if task_name == "institution_analysis":
            return {"items": [
                {
                    "制度问题": "平台劳动者是否应当通过劳动关系认定获得完整劳动法保护。",
                    "规则目的": "降低劳动者因身份不明而无法获得工资、工伤、社保和救济保护的风险。",
                    "权力配置": "平台掌握订单分配、评价规则、账号管理和收益结算权；劳动者主要承担遵守平台规则的义务。",
                    "责任分配": "争议焦点在于平台是否应承担用工主体责任、职业伤害责任和基本劳动保障责任。",
                    "证明责任": "劳动者通常需要证明平台存在管理控制、经济依赖和组织从属性，但相关证据多掌握在平台一侧。",
                    "程序后果": "劳动关系认定结果会直接影响仲裁受理、工伤认定、社保待遇和民事赔偿路径。",
                    "可写作价值": "可以作为论文的制度分析主轴。"
                },
                {
                    "制度问题": "职业伤害保障能否替代劳动关系认定。",
                    "规则目的": "在劳动关系难以认定时提供最低限度风险保障。",
                    "权力配置": "监管机关、平台企业和劳动者之间形成分担型保障结构。",
                    "责任分配": "平台承担缴费或协助保障义务，劳动者获得职业伤害救济。",
                    "证明责任": "重点转向劳动过程中受伤事实、平台任务关联性和事故因果关系。",
                    "程序后果": "可以绕开部分劳动关系认定争议，但不能完全替代工资、工时、解雇保护等劳动法制度。",
                    "可写作价值": "适合作为分层保护路径的边界分析。"
                }
            ]}

        if task_name == "case_matrix":
            return {"items": [
                {
                    "案件或判词名称": "示例平台用工争议材料",
                    "事实要点": "劳动者通过平台接单，接受派单规则、评价机制和账号管理约束。",
                    "争议焦点": "平台控制是否足以构成劳动关系中的从属性。",
                    "裁判理由": "需要围绕人格从属性、经济从属性、组织从属性以及平台实际控制强度展开判断。",
                    "规则依据": "示例材料未列明具体法条或案例编号，需核验原文。",
                    "制度功能": "展示抽象认定标准如何在具体争议中运行。",
                    "风险提示": "不得把示例输出直接作为真实案例引用。"
                }
            ]}

        if task_name == "research_gap":
            return {
                "existing_research": [
                    "已有研究较多讨论平台用工是否构成劳动关系。",
                    "已有研究开始关注职业伤害保障、集体协商和分层保护路径。",
                    "政策材料提供了权益保障的规范方向。"
                ],
                "gaps": [
                    "对平台控制事实如何被裁判者识别的分析不足。",
                    "对证明责任如何影响平台劳动者败诉或胜诉的研究不足。",
                    "对政策保护路径与劳动关系认定之间边界关系的讨论仍可深化。"
                ],
                "candidate_topics": [
                    "平台用工劳动关系认定中的证明责任研究",
                    "新就业形态劳动者职业伤害保障制度的功能与边界",
                    "算法控制视角下平台劳动者权益保障研究"
                ],
                "recommended_topic": "平台用工劳动关系认定中的证明责任研究",
                "why": "该题目材料边界清楚，可通过政策文本、裁判案例和学术文献共同支撑；同时问题具有可证伪性，可以检验证明责任配置是否实际影响权利救济效果。"
            }

        if task_name == "thesis_plan":
            return {
                "problem_consciousness": "平台用工争议中，劳动者是否受劳动法保护往往取决于劳动关系认定；但平台控制事实隐藏在算法规则、派单机制和账号管理中，劳动者证明困难，导致制度保护可能在程序层面被削弱。",
                "hypotheses": [
                    "如果平台控制事实由平台掌握，而证明责任主要由劳动者承担，则劳动者获得劳动法保护的难度会提高。",
                    "职业伤害保障可以补充救济不足，但不能完全替代劳动关系认定。",
                    "裁判者对算法控制事实的识别方式，会影响平台用工案件的规则适用结果。"
                ],
                "chapter_outline": [
                    {
                        "chapter": "第一章 绪论",
                        "content": "说明研究对象、问题意识、材料范围和研究方法。"
                    },
                    {
                        "chapter": "第二章 文献综述",
                        "content": "归纳劳动关系认定、平台用工治理、职业伤害保障和集体协商研究。"
                    },
                    {
                        "chapter": "第三章 平台用工中的制度结构",
                        "content": "分析平台控制、责任分配、证明责任和程序后果。"
                    },
                    {
                        "chapter": "第四章 证明责任对权利救济的影响",
                        "content": "结合案例或判词要素，分析平台控制事实如何被识别。"
                    },
                    {
                        "chapter": "第五章 制度完善路径",
                        "content": "提出证据披露、举证责任调整、职业伤害保障和协商机制的组合方案。"
                    }
                ],
                "expected_outputs": ["文献综述矩阵", "制度问题表", "案例要素表", "论文大纲", "风险校验表"]
            }

        if task_name == "verification":
            return {
                "fabrication_risk": [
                    "模型输出中的法条、案例、文献名称必须回到原文核验。",
                    "示例模式下的案例名称不能作为真实案例引用。"
                ],
                "evidence_gaps": [
                    "需要补充真实裁判文书或政策文件编号。",
                    "需要为每个核心判断补充出处和页码。"
                ],
                "concept_confusion": [
                    "应区分劳动关系认定、职业伤害保障和社会保险制度，三者不能互相替代。",
                    "应区分规则目的、制度功能和程序后果。"
                ],
                "logic_jumps": [
                    "不能仅凭个别案例推出平台用工整体规律。",
                    "不能把政策倡导直接等同于法律强制义务。"
                ],
                "revision_advice": [
                    "建立真实文献矩阵并标明出处。",
                    "补充3到5个真实裁判案例进行要素抽取。",
                    "把每一章的结论与材料证据一一对应。"
                ]
            }

        return {"result": "mock response"}

    def usage_summary(self) -> Dict[str, Any]:
        total_est = sum(int(r.get("total_tokens_est") or 0) for r in self.usage_records)
        total_real = sum(int(r.get("total_tokens") or 0) for r in self.usage_records if r.get("total_tokens"))
        return {
            "model": self.model,
            "base_url": self.base_url,
            "mock_mode": self.mock_mode,
            "records": self.usage_records,
            "total_tokens_est": total_est,
            "total_tokens": total_real or None,
            "notes": "mock 模式用于演示完整流程；真实模型调用时，如平台返回 usage，则 total_tokens 为真实消耗，否则使用 total_tokens_est 估算。"
        }
