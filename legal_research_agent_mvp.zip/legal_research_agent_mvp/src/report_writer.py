import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd

from .schemas import AgentResult


def write_outputs(result: AgentResult, out_dir: str | Path) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    (out / "research_report.md").write_text(build_markdown_report(result), encoding="utf-8")
    (out / "research_data.json").write_text(
        json.dumps(asdict(result), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (out / "token_usage.json").write_text(
        json.dumps(result.token_usage, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    write_csv(result.literature_matrix, out / "literature_matrix.csv")
    write_csv(result.institution_analysis, out / "institution_analysis.csv")
    write_csv(result.case_matrix, out / "case_matrix.csv")


def write_csv(items: List[Dict[str, Any]], path: Path) -> None:
    if items:
        pd.DataFrame(items).to_csv(path, index=False, encoding="utf-8-sig")
    else:
        pd.DataFrame().to_csv(path, index=False, encoding="utf-8-sig")


def markdown_table(items: List[Dict[str, Any]]) -> str:
    if not items:
        return "无。"
    columns = list(items[0].keys())
    lines = ["| " + " | ".join(columns) + " |"]
    lines.append("| " + " | ".join(["---"] * len(columns)) + " |")
    for item in items:
        row = []
        for col in columns:
            value = item.get(col, "")
            if isinstance(value, list):
                value = "；".join(str(x) for x in value)
            row.append(str(value).replace("\n", "<br>"))
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


def json_block(data: Dict[str, Any]) -> str:
    return "```json\n" + json.dumps(data, ensure_ascii=False, indent=2) + "\n```"


def build_markdown_report(result: AgentResult) -> str:
    lines = [
        "# 法学多材料研究 Agent 报告",
        "",
        "## 研究主题",
        "",
        result.topic,
        "",
        "## 一、输入材料",
        "",
    ]

    for mat in result.materials:
        lines.append(f"- {mat.filename}｜{mat.source_type}｜{mat.char_count} 字符")

    lines += ["", "## 二、单份材料摘要"]
    for item in result.document_summaries:
        lines += [
            "",
            f"### {item.get('filename', '未命名材料')}",
            f"- 材料类型：{item.get('source_type', '')}",
            f"- 研究对象：{item.get('research_object', '')}",
            f"- 核心概念：{', '.join(item.get('core_concepts', []) or [])}",
            f"- 核心观点：{item.get('main_argument', '')}",
            f"- 可用依据：{'; '.join(item.get('usable_evidence', []) or [])}",
            f"- 可用于：{item.get('possible_use', '')}",
            f"- 风险：{'; '.join(item.get('risks', []) or [])}",
        ]

    lines += [
        "",
        "## 三、文献综述矩阵",
        markdown_table(result.literature_matrix),
        "",
        "## 四、制度问题分析表",
        markdown_table(result.institution_analysis),
        "",
        "## 五、案例 / 判词要素表",
        markdown_table(result.case_matrix),
        "",
        "## 六、研究空白与选题比较",
        json_block(result.research_gap),
        "",
        "## 七、论文写作方案",
        json_block(result.thesis_plan),
        "",
        "## 八、反向校验报告",
        json_block(result.verification),
        "",
        "## 九、Token / Credits 消耗估算",
        json_block(result.token_usage),
        "",
        "> 注意：本报告由 Agent 生成，正式论文写作前必须回到原始文献、法条和案例原文核验。"
    ]
    return "\n".join(lines)
