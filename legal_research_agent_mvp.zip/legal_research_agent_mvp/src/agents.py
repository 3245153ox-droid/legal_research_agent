from typing import Any, Dict, List

from .llm_client import LLMClient
from .schemas import AgentResult, Material


SYSTEM_PROMPT = """你是一个严谨的法学硕士论文研究 Agent。
你的任务是把论文、法规、政策、案例、判词和研究笔记转化为结构化研究成果。
必须遵守：
1. 不得虚构文献、法条、案例、数据或页码。
2. 不确定的信息必须标注“需核验”。
3. 法学分析优先从规则目的、制度功能、权力配置、责任分配、证明责任、程序后果展开。
4. 输出必须是合法 JSON，不要输出 Markdown，不要添加 JSON 以外的解释。
"""


class LegalResearchAgent:
    def __init__(self, llm: LLMClient, max_chars_per_doc: int = 12000) -> None:
        self.llm = llm
        self.max_chars_per_doc = max_chars_per_doc

    def run(self, topic: str, materials: List[Material]) -> AgentResult:
        result = AgentResult(topic=topic, materials=materials)

        result.document_summaries = self.summarize_documents(topic, materials)
        result.literature_matrix = self.build_literature_matrix(topic, result.document_summaries)
        result.institution_analysis = self.analyze_institution(topic, result.document_summaries)
        result.case_matrix = self.extract_case_matrix(topic, result.document_summaries)
        result.research_gap = self.find_research_gap(topic, result)
        result.thesis_plan = self.generate_thesis_plan(topic, result)
        result.verification = self.verify_outputs(topic, result)
        result.token_usage = self.llm.usage_summary()
        return result

    def crop(self, text: str) -> str:
        if len(text) <= self.max_chars_per_doc:
            return text
        head = text[: int(self.max_chars_per_doc * 0.65)]
        tail = text[-int(self.max_chars_per_doc * 0.25):]
        return head + "\n\n[中间文本因长度限制省略，正式结论需回到原文核验]\n\n" + tail

    def summarize_documents(self, topic: str, materials: List[Material]) -> List[Dict[str, Any]]:
        summaries = []
        for mat in materials:
            prompt = f"""
研究主题：{topic}

请分析以下材料，输出 JSON：
{{
  "filename": "{mat.filename}",
  "source_type": "{mat.source_type}",
  "research_object": "",
  "core_concepts": [],
  "main_argument": "",
  "usable_evidence": [],
  "possible_use": "",
  "risks": []
}}

材料正文：
{self.crop(mat.text)}
"""
            data = self.llm.chat_json(SYSTEM_PROMPT, prompt, task_name="document_summary")
            data["filename"] = mat.filename
            data["source_type"] = mat.source_type
            summaries.append(data)
        return summaries

    def build_literature_matrix(self, topic: str, summaries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        prompt = f"""
研究主题：{topic}
材料摘要：{summaries}

请生成“文献综述矩阵”，输出 JSON：
{{
  "items": [
    {{
      "文献名称": "",
      "材料类型": "",
      "研究对象": "",
      "核心观点": "",
      "解决的问题": "",
      "留下的空白": "",
      "可用于论文位置": ""
    }}
  ]
}}
"""
        data = self.llm.chat_json(SYSTEM_PROMPT, prompt, task_name="literature_matrix")
        return data.get("items", [])

    def analyze_institution(self, topic: str, summaries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        prompt = f"""
研究主题：{topic}
材料摘要：{summaries}

请生成“制度问题分析表”，输出 JSON：
{{
  "items": [
    {{
      "制度问题": "",
      "规则目的": "",
      "权力配置": "",
      "责任分配": "",
      "证明责任": "",
      "程序后果": "",
      "可写作价值": ""
    }}
  ]
}}
"""
        data = self.llm.chat_json(SYSTEM_PROMPT, prompt, task_name="institution_analysis")
        return data.get("items", [])

    def extract_case_matrix(self, topic: str, summaries: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        prompt = f"""
研究主题：{topic}
材料摘要：{summaries}

请抽取案例/判词要素，输出 JSON：
{{
  "items": [
    {{
      "案件或判词名称": "",
      "事实要点": "",
      "争议焦点": "",
      "裁判理由": "",
      "规则依据": "",
      "制度功能": "",
      "风险提示": ""
    }}
  ]
}}

没有案例/判词时，items 为空数组。
"""
        data = self.llm.chat_json(SYSTEM_PROMPT, prompt, task_name="case_matrix")
        return data.get("items", [])

    def find_research_gap(self, topic: str, result: AgentResult) -> Dict[str, Any]:
        prompt = f"""
研究主题：{topic}
文献矩阵：{result.literature_matrix}
制度问题表：{result.institution_analysis}
案例/判词要素表：{result.case_matrix}

请生成研究空白与选题比较，输出 JSON：
{{
  "existing_research": [],
  "gaps": [],
  "candidate_topics": [],
  "recommended_topic": "",
  "why": ""
}}
"""
        return self.llm.chat_json(SYSTEM_PROMPT, prompt, task_name="research_gap")

    def generate_thesis_plan(self, topic: str, result: AgentResult) -> Dict[str, Any]:
        prompt = f"""
研究主题：{topic}
研究空白：{result.research_gap}
文献矩阵：{result.literature_matrix}
制度问题表：{result.institution_analysis}
案例/判词要素表：{result.case_matrix}

请生成论文写作方案，输出 JSON：
{{
  "problem_consciousness": "",
  "hypotheses": [],
  "chapter_outline": [
    {{"chapter": "", "content": ""}}
  ],
  "expected_outputs": []
}}
"""
        return self.llm.chat_json(SYSTEM_PROMPT, prompt, task_name="thesis_plan")

    def verify_outputs(self, topic: str, result: AgentResult) -> Dict[str, Any]:
        prompt = f"""
研究主题：{topic}

请对以下 Agent 输出进行反向校验：
文献矩阵：{result.literature_matrix}
制度问题表：{result.institution_analysis}
案例/判词要素表：{result.case_matrix}
研究空白：{result.research_gap}
论文方案：{result.thesis_plan}

输出 JSON：
{{
  "fabrication_risk": [],
  "evidence_gaps": [],
  "concept_confusion": [],
  "logic_jumps": [],
  "revision_advice": []
}}
"""
        return self.llm.chat_json(SYSTEM_PROMPT, prompt, task_name="verification")
